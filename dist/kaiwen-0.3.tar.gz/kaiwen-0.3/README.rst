Github
======

https://github.com/kxue4/kaiwen

kaiwen
==================

Mainly for personal use

version
==================

v0.3

how to install
==============

::

    pip install kaiwen

What's include
==========

**Two easy re functions:**
type: return type, include [list or None]
ext: [reversed or None]

::
        extract_chinese_characters(string, type=None, ext=None)
        extract_numbers(string, type=None, ext=None)

**Some other useful functions:**

::

        bubble_sort(list)
        calculate_pi(digits)
        english_format_checker(string)
        generate_coupon(num, digit_num)
        merge_dicts(*args)
        multiline_input()
        recursion.sum_it(list)
        recursion.quick_sort(list)
        word_filter(string)